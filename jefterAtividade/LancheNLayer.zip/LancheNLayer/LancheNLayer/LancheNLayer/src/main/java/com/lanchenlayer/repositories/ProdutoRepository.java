package com.lanchenlayer.repositories;

import com.lanchenlayer.entities.Produto;

import java.util.ArrayList;
import java.util.Scanner;

public class ProdutoRepository {
    private ArrayList<Produto> produtos = new ArrayList<Produto>();

    public void adicionar(Produto produto) {
        produtos.add(produto);
    }

    public void atualizar(Produto produto, int index) {
        produtos.set(index, produto);
    }

    public void atualizarProduto(Produto produto) {
        Scanner scan = new Scanner(System.in);

        System.out.println("Selecione o ID do produto: ");
        int id = scan.nextInt();
        buscarPorId(id);

        System.out.println("Atualizar id:");
        int novoId = scan.nextInt();

        System.out.println("Atualizar descricao:");
        String novaDescricao = scan.nextLine();
        scan.next();

        System.out.println("Atualizar imagem:");
        String novaImagem = scan.nextLine();
        scan.next();

        System.out.println("Atualizar valor");
        float novoValor = scan.nextFloat();

        produto.setId(novoId);
        produto.setDescricao(novaDescricao);
        produto.setValor(novoValor);
        produto.setImagem(novaImagem);

    }

    public void remover(int id) {
        produtos.removeIf(produto -> produto.getId() == id);
    }

    public Produto buscarPorId(int id) {
        Produto produtoInDb = produtos.stream().filter(p -> p.getId() == id).findFirst().get();

        return produtoInDb;
    }

    public ArrayList<Produto> buscarTodos() {
        return produtos;
    }
}
