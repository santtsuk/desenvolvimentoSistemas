package org.venda;

import java.util.ArrayList;
import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        ListaDeProdutos listaDeProdutos = new ListaDeProdutos();

        boolean continuar = true;
        System.out.println("Bem-vindo!");
        Scanner scan = new Scanner(System.in);

        while (continuar) {
            int escolha = menu(scan);

            switch (escolha) {

                case 1:
                    System.out.println("Nome do produto");
                    String nome = scan.nextLine();

                    System.out.println("Valor do Produto");
                    float valor = scan.nextFloat();
                    scan.nextLine();

                    System.out.println("Descricao do produto");
                    String descricao = scan.nextLine();

                    System.out.println("Imagem do produto");
                    String imagem = scan.nextLine();

                    Produto produto = new Produto(nome, valor, descricao, imagem);
                    listaDeProdutos.novoProduto(produto);

                    break;

                case 2:
                    listaDeProdutos.consultarProdutos();
                    System.out.println("Retorne ao menu digitando qualquer tecla");
                    scan.nextLine();
                    break;

                case 3:
                    int remover;

                    System.out.println("Escolha o produto que deseja remover (pelo índice):");
                    remover = scan.nextInt() - 1;
                    if (remover >= 0 && remover < listaDeProdutos.produtos.size()) {
                        listaDeProdutos.removerProduto(remover);
                        System.out.println("Produto removido com sucesso!");
                    } else {
                        System.out.println("Índice inválido. Nenhum produto foi removido.");
                    }
                    break;

                case 4:
                    listaDeProdutos.mostrarProduto();

                    break;
                case 5:
                    System.exit(1);

                default:
                    System.out.println("Opção inválida! Escolha uma das opções abaixo.");
                    break;

            }
        }
    }

    public static int menu(Scanner scan) {
        System.out.println("\nEscolha qual operação deseja realizar:\n"
                + "1 - Adicionar um produto\n"
                + "2 - Listar produtos\n"
                + "3 - Remover um produto\n"
                + "4 - Fazer compra do produto\n"
                + "5 - Sair");

        int escolha = scan.nextInt();
        scan.nextLine(); // Limpar o buffer de entrada
        return escolha;
    }
}
