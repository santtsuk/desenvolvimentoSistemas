package org.venda;

import java.util.ArrayList;
import java.util.Scanner;

public class ListaDeProdutos {

    ArrayList<Produto> produtos = new ArrayList<>(10);

    public void novoProduto(Produto produto) {
        produtos.add(produto);
    }

    public void removerProduto(int produto) {
        produtos.remove(produto);
    }

    public void consultarProdutos() {
        for (Produto produto : produtos) {
            System.out.println("_________________________________");
            System.out.println("Nome: " + produto.getNome());
            System.out.println("Valor: R$" + produto.getValor());
            System.out.println("Descrição: " + produto.getDescricao());
            System.out.println("Caminho da Imagem: " + produto.getImagem());
            System.out.println("_________________________________");
        }
    }

    public void mostrarProduto() {
        Scanner scan = new Scanner(System.in);

        // Solicitar a posição do produto ao usuário
        System.out.println("Digite a posição do produto que deseja visualizar (começando de 0):");
        int posicaoProduto = scan.nextInt() + 1;
        scan.nextLine();

        if (posicaoProduto >= 1 && posicaoProduto < produtos.size()) {
            Produto produto = produtos.get(posicaoProduto);

            System.out.println("Nome: " + produto.getNome());

            System.out.println("Valor: " + produto.getValor());

            System.out.println("Escolha a quantidade desejada:");
            int quantidade = scan.nextInt();
            float valorTotal = (float) (produto.getValor() * quantidade);

            System.out.println("Valor total: " + valorTotal);

        } else {
            System.out.println("Produto não encontrado.");
        }
    }
}